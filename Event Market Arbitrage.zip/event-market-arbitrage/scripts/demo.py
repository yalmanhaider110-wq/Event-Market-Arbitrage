from decimal import Decimal

from event_arb.arbitrage.fees import FeeModel
from event_arb.arbitrage.scanners import scan_exhaustive_basket, scan_implication_arbitrage
from event_arb.models import BinaryOrderBook, PriceLevel


def book(ticker: str, yes_bid: str, no_bid: str, qty: str = "100") -> BinaryOrderBook:
    return BinaryOrderBook(
        ticker,
        [PriceLevel(Decimal(yes_bid), Decimal(qty))],
        [PriceLevel(Decimal(no_bid), Decimal(qty))],
    )


fees = FeeModel()

# Three exhaustive outcomes with YES asks 0.30 + 0.30 + 0.30 = 0.90 before fees.
a = book("A", "0.68", "0.70")
b = book("B", "0.68", "0.70")
c = book("C", "0.68", "0.70")
print(scan_exhaustive_basket("demo basket", [a, b, c], True, fees))

# A => B. NO(A) ask=0.20 and YES(B) ask=0.70, locking >=1.00 payout.
a2 = book("A_GT90", "0.80", "0.18")
b2 = book("B_GT85", "0.28", "0.30")
print(scan_implication_arbitrage("demo implication", a2, b2, fees))
