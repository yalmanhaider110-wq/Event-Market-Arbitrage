import asyncio

import pytest

from event_arb.kalshi import ws


@pytest.mark.parametrize("exported", [False, True])
def test_collector_loads_dotenv_without_overriding_environment(tmp_path, monkeypatch, exported):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text(
        "KALSHI_API_KEY_ID=file-id\nKALSHI_PRIVATE_KEY_PATH=file.pem\n",
        encoding="utf-8",
    )
    monkeypatch.delenv("KALSHI_API_KEY_ID", raising=False)
    monkeypatch.delenv("KALSHI_PRIVATE_KEY_PATH", raising=False)
    if exported:
        monkeypatch.setenv("KALSHI_API_KEY_ID", "exported-id")
        monkeypatch.setenv("KALSHI_PRIVATE_KEY_PATH", "exported.pem")

    captured = {}

    def fake_auth(key_id, key_path):
        captured.update(key_id=key_id, key_path=key_path)
        return {}

    class FakeSocket:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def send(self, message):
            captured["subscription"] = message

        def __aiter__(self):
            return self

        async def __anext__(self):
            raise StopAsyncIteration

    monkeypatch.setattr(ws, "_auth_headers", fake_auth)
    monkeypatch.setattr(ws.websockets, "connect", lambda *args, **kwargs: FakeSocket())
    asyncio.run(ws.collect_orderbook_stream("wss://example.invalid", ["TEST"], "books.jsonl"))
    assert captured["key_id"] == ("exported-id" if exported else "file-id")
    assert captured["key_path"] == ("exported.pem" if exported else "file.pem")
    assert '"TEST"' in captured["subscription"]
