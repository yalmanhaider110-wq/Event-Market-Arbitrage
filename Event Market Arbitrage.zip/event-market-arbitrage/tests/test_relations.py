from pathlib import Path

from event_arb.arbitrage.relations import load_relations


def test_load_relations(tmp_path: Path):
    p = tmp_path / "relations.yaml"
    p.write_text(
        """
baskets:
  - name: outcomes
    tickers: [A, B]
    exhaustive: true
implications:
  - name: nested
    antecedent: A
    consequent: B
""",
        encoding="utf-8",
    )
    rels = load_relations(p)
    assert rels.baskets[0].exhaustive is True
    assert rels.implications[0].antecedent == "A"
