from decimal import Decimal

from event_arb.arbitrage.fees import FeeModel
from event_arb.arbitrage.scanners import (
    implication_consistency_signal,
    scan_complement_arbitrage,
    scan_exhaustive_basket,
    scan_implication_arbitrage,
)
from event_arb.models import BinaryOrderBook, PriceLevel


def book(ticker: str, yes_bid: str, no_bid: str, qty: str = "100") -> BinaryOrderBook:
    return BinaryOrderBook(
        ticker=ticker,
        yes_bids=[PriceLevel(Decimal(yes_bid), Decimal(qty))],
        no_bids=[PriceLevel(Decimal(no_bid), Decimal(qty))],
    )


def test_complement_arbitrage_detected():
    # YES ask = .50; NO ask = .40; total .90.
    b = book("X", yes_bid="0.60", no_bid="0.50")
    opp = scan_complement_arbitrage(b, FeeModel(), Decimal("0"), Decimal("1"))
    assert opp is not None
    assert opp.net_profit > 0
    assert opp.guaranteed_payout == Decimal("100")


def test_exhaustive_basket_requires_explicit_verification():
    books = [book("A", "0.68", "0.70"), book("B", "0.68", "0.70"), book("C", "0.68", "0.70")]
    assert scan_exhaustive_basket("x", books, False, FeeModel()) == []
    opps = scan_exhaustive_basket("x", books, True, FeeModel())
    assert any(x.opportunity_type == "exhaustive_basket_underpriced" for x in opps)


def test_implication_arbitrage_and_signal():
    a = book("A", "0.80", "0.18")
    b = book("B", "0.28", "0.30")
    signal = implication_consistency_signal(a, b)
    assert signal is not None
    assert Decimal(signal["executable_probability_gap"]) == Decimal("0.10")

    opp = scan_implication_arbitrage("A implies B", a, b, FeeModel())
    assert opp is not None
    assert opp.net_profit > 0
