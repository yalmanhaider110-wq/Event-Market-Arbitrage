from decimal import Decimal

from event_arb.kalshi.orderbook import parse_orderbook


def test_bid_to_ask_mapping_and_sweep():
    payload = {
        "orderbook_fp": {
            "yes_dollars": [["0.40", "10"], ["0.42", "20"]],
            "no_dollars": [["0.55", "5"], ["0.56", "15"]],
        }
    }
    book = parse_orderbook("TEST", payload)
    assert book.best_bid("yes") == Decimal("0.42")
    assert book.best_ask("yes") == Decimal("0.44")
    assert book.best_ask("no") == Decimal("0.58")

    execution = book.sweep_buy("yes", Decimal("18"))
    assert execution.fully_filled
    assert execution.gross_cost == Decimal("7.95")  # 15*.44 + 3*.45
    assert execution.average_price == Decimal("7.95") / Decimal("18")
