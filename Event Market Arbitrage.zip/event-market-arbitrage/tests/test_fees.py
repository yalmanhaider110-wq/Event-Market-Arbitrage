from decimal import Decimal

from event_arb.arbitrage.fees import FeeModel


def test_standard_taker_fee():
    model = FeeModel()
    # 0.07 * 100 * .30 * .70 = 1.47
    assert model.trade_fee(Decimal("0.30"), Decimal("100")) == Decimal("1.47")


def test_fee_rounds_up_to_cent():
    model = FeeModel()
    assert model.trade_fee(Decimal("0.50"), Decimal("1")) == Decimal("0.02")
