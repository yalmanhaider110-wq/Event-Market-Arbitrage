from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(page_title="Event Market Arbitrage Monitor", layout="wide")
st.title("Event Market Arbitrage Monitor")
st.caption("Research / paper-trading dashboard. No live order submission.")

path = Path("results/opportunities.csv")
if not path.exists():
    st.info("No logged opportunities yet. Run: event-arb scan --relations relations.yaml")
    st.stop()

try:
    df = pd.read_csv(path)
except pd.errors.EmptyDataError:
    st.info("The opportunity log is empty.")
    st.stop()

if df.empty:
    st.info("No executable opportunities have been logged yet.")
    st.stop()

for col in ["net_profit", "net_edge_per_contract", "gross_cost", "fees", "guaranteed_payout", "quantity"]:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Logged opportunities", len(df))
c2.metric("Total theoretical net P&L", f"${df['net_profit'].sum():,.2f}")
c3.metric("Median edge / contract", f"${df['net_edge_per_contract'].median():.4f}")
c4.metric("Largest executable size", f"{df['quantity'].max():,.0f}")

st.subheader("Top opportunities")
st.dataframe(
    df.sort_values("net_profit", ascending=False),
    use_container_width=True,
    hide_index=True,
)

if "observed_at" in df.columns:
    chart = df.copy()
    chart["observed_at"] = pd.to_datetime(chart["observed_at"], errors="coerce")
    chart = chart.dropna(subset=["observed_at"]).set_index("observed_at")
    if not chart.empty:
        st.subheader("Net edge over time")
        st.line_chart(chart[["net_edge_per_contract"]])
