# Interview Guide

## 30-second pitch

I built a read-only event-market relative-value engine for Kalshi. It reconstructs executable asks from Kalshi's bid-only binary order books, walks actual depth, applies transaction costs, and tests no-arbitrage relationships across complementary, exhaustive, and logically nested contracts. I deliberately separate true guaranteed-payoff arbitrage from statistical or logical mispricing signals, and I added a WebSocket recorder so I can build a prospective L2 dataset for more realistic backtests.

## 90-second technical explanation

The key market-microstructure detail is that Kalshi's REST order book gives YES and NO bids rather than separate asks. In a binary contract, a NO bid at price `p` is equivalent to a YES ask at `1-p`, so I normalize both sides into executable bid/ask ladders using fixed-point Decimal arithmetic.

From there I define payoff constraints. For a single binary contract, buying YES and NO guarantees a $1 settlement. For an exactly-one-outcome basket, buying every YES guarantees $1, while buying every NO guarantees `n-1` dollars. For a logical relation `A => B`, buying `NO(A) + YES(B)` guarantees at least $1 in every valid state.

The engine walks depth across every leg, applies a configurable fee model with conservative per-price-level rounding, and only reports an arbitrage if minimum settlement value exceeds observed execution cost plus fees. If prices violate a probability constraint but that inequality is not executable after costs, I report it as a consistency signal instead of arbitrage.

## Questions you should be ready for

### Why isn't a price sum below 1 automatically arbitrage?

Because displayed or midpoint prices may not be executable, available size can differ across legs, transaction fees matter, and a set of outcomes may be mutually exclusive without being exhaustive. Settlement rules must establish the payoff identity.

### Why use Decimal rather than float?

The API represents fixed-point prices and quantities. Decimal avoids binary floating-point artifacts in money calculations, complements such as `1-p`, and fee thresholds.

### Why does the scanner examine depth breakpoints?

The marginal execution price changes only when a consumed price level is exhausted. Evaluating common depth breakpoints lets the engine find the quantity that maximizes theoretical net P&L without brute-forcing every possible size.

### Why call the WebSocket dataset prospective?

Trades and candlesticks cannot reconstruct the historical L2 queue. To study fleeting opportunities, sequence gaps, and queue/legging risk, order-book snapshots and deltas need to be captured as they occur.

### Is a detected snapshot arbitrage guaranteed to be realizable?

No. The payoff can be guaranteed if all legs fill at the observed prices, but execution is not atomic. Between observing the book and completing all legs, prices or available quantities can move. That is why the repository calls the output theoretical executable opportunities under snapshot/atomic-fill assumptions rather than realized profit.

### What would you add next?

1. Event- and series-level fee overrides from exchange metadata.
2. WebSocket state reconstruction with sequence-gap recovery.
3. Legging-risk simulation using message timestamps.
4. Queue-aware maker-fill simulation.
5. Capital-lockup and annualized-return metrics.
6. Automated rule-link verification for selected market families.
7. Cross-venue or options-implied fair-value comparisons.

## Resume bullet

> Built a Python event-market relative-value engine that ingests live Kalshi L2 books, detects logical pricing violations across binary and multi-outcome contracts, and filters opportunities for transaction fees and executable depth; captured WebSocket snapshots/deltas for prospective microstructure backtesting.

After collecting real data, replace generic language with reproducible metrics such as markets scanned, observations captured, median opportunity duration, and fraction of raw violations surviving fees and depth filters.
