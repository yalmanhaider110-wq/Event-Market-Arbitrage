from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Literal

Side = Literal["yes", "no"]


@dataclass(frozen=True)
class PriceLevel:
    price: Decimal
    quantity: Decimal

    def __post_init__(self) -> None:
        if not (Decimal("0") <= self.price <= Decimal("1")):
            raise ValueError(f"Price must be in [0, 1], got {self.price}")
        if self.quantity < 0:
            raise ValueError("Quantity cannot be negative")


@dataclass
class ExecutionEstimate:
    side: Side
    requested: Decimal
    filled: Decimal
    gross_cost: Decimal
    average_price: Decimal | None
    levels_used: list[PriceLevel] = field(default_factory=list)

    @property
    def fully_filled(self) -> bool:
        return self.filled >= self.requested


@dataclass
class BinaryOrderBook:
    ticker: str
    yes_bids: list[PriceLevel]
    no_bids: list[PriceLevel]
    observed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        self.yes_bids = sorted(self.yes_bids, key=lambda x: x.price)
        self.no_bids = sorted(self.no_bids, key=lambda x: x.price)

    @staticmethod
    def _asks_from_opposite_bids(bids: list[PriceLevel]) -> list[PriceLevel]:
        # A NO bid at p is a YES ask at 1-p, and vice versa.
        asks = [PriceLevel(Decimal("1") - x.price, x.quantity) for x in bids]
        return sorted(asks, key=lambda x: x.price)

    @property
    def yes_asks(self) -> list[PriceLevel]:
        return self._asks_from_opposite_bids(self.no_bids)

    @property
    def no_asks(self) -> list[PriceLevel]:
        return self._asks_from_opposite_bids(self.yes_bids)

    def best_bid(self, side: Side) -> Decimal | None:
        levels = self.yes_bids if side == "yes" else self.no_bids
        return levels[-1].price if levels else None

    def best_ask(self, side: Side) -> Decimal | None:
        levels = self.yes_asks if side == "yes" else self.no_asks
        return levels[0].price if levels else None

    def best_ask_size(self, side: Side) -> Decimal:
        levels = self.yes_asks if side == "yes" else self.no_asks
        return levels[0].quantity if levels else Decimal("0")

    def sweep_buy(self, side: Side, quantity: Decimal) -> ExecutionEstimate:
        if quantity <= 0:
            raise ValueError("quantity must be positive")
        asks = self.yes_asks if side == "yes" else self.no_asks
        remaining = quantity
        cost = Decimal("0")
        used: list[PriceLevel] = []
        for level in asks:
            if remaining <= 0:
                break
            take = min(remaining, level.quantity)
            if take > 0:
                cost += take * level.price
                used.append(PriceLevel(level.price, take))
                remaining -= take
        filled = quantity - remaining
        avg = (cost / filled) if filled > 0 else None
        return ExecutionEstimate(side, quantity, filled, cost, avg, used)


@dataclass(frozen=True)
class Market:
    ticker: str
    event_ticker: str | None
    title: str
    subtitle: str | None
    status: str | None
    yes_bid: Decimal | None
    yes_ask: Decimal | None
    no_bid: Decimal | None
    no_ask: Decimal | None
    volume: Decimal | None = None
    open_interest: Decimal | None = None
    close_time: str | None = None
    rules_primary: str | None = None
    rules_secondary: str | None = None


@dataclass(frozen=True)
class Opportunity:
    opportunity_type: str
    label: str
    tickers: tuple[str, ...]
    quantity: Decimal
    gross_cost: Decimal
    guaranteed_payout: Decimal
    fees: Decimal
    net_profit: Decimal
    net_edge_per_contract: Decimal
    observed_at: datetime
    details: dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict[str, str]:
        return {
            "opportunity_type": self.opportunity_type,
            "label": self.label,
            "tickers": ",".join(self.tickers),
            "quantity": str(self.quantity),
            "gross_cost": str(self.gross_cost),
            "guaranteed_payout": str(self.guaranteed_payout),
            "fees": str(self.fees),
            "net_profit": str(self.net_profit),
            "net_edge_per_contract": str(self.net_edge_per_contract),
            "observed_at": self.observed_at.isoformat(),
            **{f"detail_{k}": v for k, v in self.details.items()},
        }
