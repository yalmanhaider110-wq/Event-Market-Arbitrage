from __future__ import annotations

import argparse

from rich.console import Console
from rich.table import Table

from event_arb.arbitrage import (
    FeeModel,
    implication_consistency_signal,
    scan_complement_arbitrage,
    scan_exhaustive_basket,
    scan_implication_arbitrage,
)
from event_arb.arbitrage.relations import load_relations
from event_arb.config import load_config
from event_arb.kalshi.client import KalshiPublicClient
from event_arb.kalshi.ws import run_collector
from event_arb.storage import append_opportunities, append_snapshot

console = Console()


def _fee_model(config) -> FeeModel:
    return FeeModel(
        taker_rate=config.fee.taker_rate,
        maker_rate=config.fee.maker_rate,
        rounding_increment=config.fee.rounding_increment,
        market_taker_rate_overrides=config.fee.market_taker_rate_overrides,
    )


def _render(opportunities) -> None:
    table = Table(title="Executable event-market opportunities")
    for col in ["Type", "Label", "Qty", "Cost", "Fees", "Payout", "Net P&L", "Edge/unit"]:
        table.add_column(col)
    for x in sorted(opportunities, key=lambda y: y.net_profit, reverse=True):
        table.add_row(
            x.opportunity_type,
            x.label,
            str(x.quantity),
            f"${x.gross_cost:.4f}",
            f"${x.fees:.4f}",
            f"${x.guaranteed_payout:.4f}",
            f"${x.net_profit:.4f}",
            f"${x.net_edge_per_contract:.4f}",
        )
    console.print(table)


def scan(args) -> None:
    cfg = load_config(args.config)
    rels = load_relations(args.relations)
    client = KalshiPublicClient(cfg.rest_base_url, cfg.request_timeout_seconds)
    markets = client.get_markets(status="open", limit=args.limit or cfg.max_markets)
    tickers = {m.ticker for m in markets}

    relation_tickers = {
        t for b in rels.baskets for t in b.tickers
    } | {t for r in rels.implications for t in (r.antecedent, r.consequent)}
    requested = sorted(tickers | relation_tickers)
    books = client.get_orderbooks(requested, depth=cfg.orderbook_depth)
    fee_model = _fee_model(cfg)
    opportunities = []

    for ticker in sorted(tickers):
        book = books.get(ticker)
        if not book:
            continue
        found = scan_complement_arbitrage(
            book,
            fee_model,
            min_net_edge=cfg.min_net_edge_dollars,
            min_quantity=cfg.min_executable_contracts,
        )
        if found:
            opportunities.append(found)
        if args.save_snapshots:
            append_snapshot(cfg.storage.snapshots_path, book)

    for relation in rels.baskets:
        relation_books = [books[t] for t in relation.tickers if t in books]
        if len(relation_books) != len(relation.tickers):
            continue
        opportunities.extend(
            scan_exhaustive_basket(
                relation.name,
                relation_books,
                relation.exhaustive,
                fee_model,
                cfg.min_net_edge_dollars,
                cfg.min_executable_contracts,
                relation.verified_rules_note,
            )
        )

    signals = []
    for relation in rels.implications:
        a = books.get(relation.antecedent)
        b = books.get(relation.consequent)
        if not a or not b:
            continue
        arb = scan_implication_arbitrage(
            relation.name,
            a,
            b,
            fee_model,
            cfg.min_net_edge_dollars,
            cfg.min_executable_contracts,
            relation.verified_rules_note,
        )
        if arb:
            opportunities.append(arb)
        signal = implication_consistency_signal(a, b)
        if signal:
            signals.append((relation.name, signal))

    _render(opportunities)
    if signals:
        console.print("\n[bold]Logical consistency signals (not necessarily arbitrage after fees):[/bold]")
        for name, s in signals:
            console.print(
                f"• {name}: {s['antecedent']} bid {s['antecedent_yes_bid']} > "
                f"{s['consequent']} ask {s['consequent_yes_ask']} "
                f"(gap {s['executable_probability_gap']})"
            )

    written = append_opportunities(cfg.storage.opportunities_path, opportunities)
    console.print(
        f"\nScanned {len(markets)} open markets; {len(books)} order books loaded; "
        f"{written} executable opportunities logged."
    )


def collect(args) -> None:
    cfg = load_config(args.config)
    run_collector(cfg.ws_url, args.tickers, args.output or cfg.storage.snapshots_path)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="event-arb",
        description="Read-only Kalshi event-market arbitrage and mispricing research engine",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="Scan live public REST order books")
    p_scan.add_argument("--config", default=None)
    p_scan.add_argument("--relations", default=None)
    p_scan.add_argument("--limit", type=int, default=None)
    p_scan.add_argument("--save-snapshots", action="store_true")
    p_scan.set_defaults(func=scan)

    p_collect = sub.add_parser("collect", help="Collect authenticated WebSocket orderbook data")
    p_collect.add_argument("tickers", nargs="+")
    p_collect.add_argument("--config", default=None)
    p_collect.add_argument("--output", default=None)
    p_collect.set_defaults(func=collect)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
