from __future__ import annotations

from pathlib import Path
from decimal import Decimal

import yaml
from pydantic import BaseModel, Field


class FeeConfig(BaseModel):
    taker_rate: Decimal = Decimal("0.07")
    maker_rate: Decimal = Decimal("0.0175")
    rounding_increment: Decimal = Decimal("0.01")
    use_maker_fee: bool = False
    market_taker_rate_overrides: dict[str, Decimal] = Field(default_factory=dict)


class StorageConfig(BaseModel):
    opportunities_path: str = "results/opportunities.csv"
    snapshots_path: str = "data/orderbook_snapshots.jsonl"


class AppConfig(BaseModel):
    rest_base_url: str = "https://external-api.kalshi.com/trade-api/v2"
    ws_url: str = "wss://external-api-ws.kalshi.com/trade-api/ws/v2"
    request_timeout_seconds: int = 10
    max_markets: int = 500
    orderbook_depth: int = Field(default=0, ge=0)
    min_net_edge_dollars: Decimal = Decimal("0.005")
    min_executable_contracts: Decimal = Decimal("1")
    fee: FeeConfig = FeeConfig()
    storage: StorageConfig = StorageConfig()


def load_config(path: str | Path | None = None) -> AppConfig:
    if path is None:
        return AppConfig()
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    return AppConfig.model_validate(raw)
