from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from event_arb.models import Opportunity


@dataclass
class PaperPortfolio:
    starting_cash: Decimal = Decimal("10000")
    cash: Decimal = field(init=False)
    locked_payout: Decimal = Decimal("0")
    fees_paid: Decimal = Decimal("0")
    opportunities_taken: int = 0

    def __post_init__(self) -> None:
        self.cash = self.starting_cash

    def take(self, opportunity: Opportunity) -> bool:
        required = opportunity.gross_cost + opportunity.fees
        if required > self.cash:
            return False
        self.cash -= required
        self.locked_payout += opportunity.guaranteed_payout
        self.fees_paid += opportunity.fees
        self.opportunities_taken += 1
        return True

    @property
    def guaranteed_terminal_value(self) -> Decimal:
        return self.cash + self.locked_payout

    @property
    def guaranteed_pnl(self) -> Decimal:
        return self.guaranteed_terminal_value - self.starting_cash
