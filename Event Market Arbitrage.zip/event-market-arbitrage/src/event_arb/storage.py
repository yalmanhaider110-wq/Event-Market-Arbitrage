from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable

from event_arb.models import BinaryOrderBook, Opportunity


def append_opportunities(path: str | Path, opportunities: Iterable[Opportunity]) -> int:
    opportunities = list(opportunities)
    if not opportunities:
        return 0
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [x.as_dict() for x in opportunities]
    all_fields = sorted({k for row in rows for k in row})
    exists = path.exists() and path.stat().st_size > 0
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_fields)
        if not exists:
            writer.writeheader()
        for row in rows:
            writer.writerow(row)
    return len(rows)


def append_snapshot(path: str | Path, book: BinaryOrderBook) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "observed_at": book.observed_at.isoformat(),
        "ticker": book.ticker,
        "yes_bids": [[str(x.price), str(x.quantity)] for x in book.yes_bids],
        "no_bids": [[str(x.price), str(x.quantity)] for x in book.no_bids],
    }
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
