from __future__ import annotations

from decimal import Decimal

from event_arb.models import BinaryOrderBook, PriceLevel


def _levels(raw: list[list[str]] | None) -> list[PriceLevel]:
    out: list[PriceLevel] = []
    for row in raw or []:
        if len(row) != 2:
            continue
        price, quantity = row
        out.append(PriceLevel(Decimal(str(price)), Decimal(str(quantity))))
    return out


def parse_orderbook(ticker: str, payload: dict) -> BinaryOrderBook:
    """Parse Kalshi's current fixed-point REST orderbook response.

    Current API responses use orderbook_fp.yes_dollars and
    orderbook_fp.no_dollars. Both are bid ladders; asks are implied from the
    opposite bid side inside BinaryOrderBook.
    """
    book = payload.get("orderbook_fp")
    if not isinstance(book, dict):
        raise ValueError("Missing orderbook_fp in response")
    return BinaryOrderBook(
        ticker=ticker,
        yes_bids=_levels(book.get("yes_dollars")),
        no_bids=_levels(book.get("no_dollars")),
    )
