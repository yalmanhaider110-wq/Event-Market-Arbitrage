from __future__ import annotations

import asyncio
import base64
import json
import os
import time
from pathlib import Path
from typing import Iterable

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
import websockets
from dotenv import load_dotenv


def _auth_headers(api_key_id: str, private_key_path: str, path: str = "/trade-api/ws/v2") -> dict[str, str]:
    ts = str(int(time.time() * 1000))
    message = f"{ts}GET{path}".encode()
    private_key = serialization.load_pem_private_key(
        Path(private_key_path).read_bytes(), password=None
    )
    signature = private_key.sign(
        message,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
        hashes.SHA256(),
    )
    return {
        "KALSHI-ACCESS-KEY": api_key_id,
        "KALSHI-ACCESS-TIMESTAMP": ts,
        "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode(),
    }


async def collect_orderbook_stream(
    ws_url: str,
    tickers: Iterable[str],
    output_path: str,
    api_key_id: str | None = None,
    private_key_path: str | None = None,
) -> None:
    """Record raw orderbook snapshots/deltas for future queue-aware research.

    No order submission exists anywhere in this module.
    """
    load_dotenv(dotenv_path=Path.cwd() / ".env", override=False)
    api_key_id = api_key_id or os.getenv("KALSHI_API_KEY_ID")
    private_key_path = private_key_path or os.getenv("KALSHI_PRIVATE_KEY_PATH")
    if not api_key_id or not private_key_path:
        raise RuntimeError("WebSocket collection requires KALSHI_API_KEY_ID and KALSHI_PRIVATE_KEY_PATH")

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    headers = _auth_headers(api_key_id, private_key_path)
    subscription = {
        "id": 1,
        "cmd": "subscribe",
        "params": {
            "channels": ["orderbook_delta"],
            "market_tickers": list(tickers),
        },
    }

    async with websockets.connect(ws_url, additional_headers=headers, ping_interval=None) as ws:
        await ws.send(json.dumps(subscription))
        async for raw in ws:
            # websockets handles protocol-level ping/pong frames automatically.
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                parsed = {"raw": raw}
            parsed["collector_received_ts_ms"] = int(time.time() * 1000)
            with out.open("a", encoding="utf-8") as f:
                f.write(json.dumps(parsed) + "\n")


def run_collector(ws_url: str, tickers: Iterable[str], output_path: str) -> None:
    asyncio.run(collect_orderbook_stream(ws_url, tickers, output_path))
