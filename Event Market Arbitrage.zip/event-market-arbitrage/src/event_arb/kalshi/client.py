from __future__ import annotations

from decimal import Decimal
from typing import Iterable

import requests

from event_arb.models import Market, BinaryOrderBook
from event_arb.kalshi.orderbook import parse_orderbook


class KalshiPublicClient:
    """Read-only Kalshi Trade API client.

    Intentionally contains no order-placement methods. This repository is a
    research/paper-trading project, not a live execution bot.
    """

    def __init__(self, base_url: str, timeout: int = 10) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "event-market-arbitrage/0.1"})

    def _get(self, path: str, params: list[tuple[str, str]] | dict | None = None) -> dict:
        response = self.session.get(
            f"{self.base_url}{path}", params=params, timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _decimal(value) -> Decimal | None:
        if value is None or value == "":
            return None
        return Decimal(str(value))

    @classmethod
    def _parse_market(cls, raw: dict) -> Market:
        return Market(
            ticker=raw["ticker"],
            event_ticker=raw.get("event_ticker"),
            title=raw.get("title") or raw.get("yes_sub_title") or raw["ticker"],
            subtitle=raw.get("subtitle") or raw.get("yes_sub_title"),
            status=raw.get("status"),
            yes_bid=cls._decimal(raw.get("yes_bid_dollars")),
            yes_ask=cls._decimal(raw.get("yes_ask_dollars")),
            no_bid=cls._decimal(raw.get("no_bid_dollars")),
            no_ask=cls._decimal(raw.get("no_ask_dollars")),
            volume=cls._decimal(raw.get("volume_fp")),
            open_interest=cls._decimal(raw.get("open_interest_fp")),
            close_time=raw.get("close_time") or raw.get("latest_expiration_time"),
            rules_primary=raw.get("rules_primary"),
            rules_secondary=raw.get("rules_secondary"),
        )

    def get_markets(self, status: str = "open", limit: int = 1000) -> list[Market]:
        markets: list[Market] = []
        cursor: str | None = None
        while len(markets) < limit:
            page_size = min(1000, limit - len(markets))
            params: dict[str, str | int] = {"limit": page_size, "status": status}
            if cursor:
                params["cursor"] = cursor
            payload = self._get("/markets", params=params)
            markets.extend(self._parse_market(x) for x in payload.get("markets", []))
            cursor = payload.get("cursor") or None
            if not cursor or not payload.get("markets"):
                break
        return markets[:limit]

    def get_market(self, ticker: str) -> Market:
        payload = self._get(f"/markets/{ticker}")
        return self._parse_market(payload.get("market", payload))

    def get_orderbook(self, ticker: str, depth: int = 0) -> BinaryOrderBook:
        params = {"depth": depth} if depth else None
        return parse_orderbook(ticker, self._get(f"/markets/{ticker}/orderbook", params=params))

    def get_orderbooks(self, tickers: Iterable[str], depth: int = 0) -> dict[str, BinaryOrderBook]:
        tickers = list(tickers)
        books: dict[str, BinaryOrderBook] = {}
        # Current batch endpoint supports repeated ticker parameters. Chunking
        # keeps requests compact and conservative.
        for i in range(0, len(tickers), 100):
            chunk = tickers[i : i + 100]
            params: list[tuple[str, str]] = [("tickers", t) for t in chunk]
            if depth:
                params.append(("depth", str(depth)))
            try:
                payload = self._get("/markets/orderbooks", params=params)
                for item in payload.get("orderbooks", []):
                    ticker = item.get("ticker")
                    if ticker:
                        books[ticker] = parse_orderbook(ticker, item)
            except requests.RequestException:
                # Keep the scanner usable if the batch endpoint is unavailable
                # in a particular API environment or changes independently.
                for ticker in chunk:
                    try:
                        books[ticker] = self.get_orderbook(ticker, depth=depth)
                    except requests.RequestException:
                        continue
        return books

    def get_event(self, event_ticker: str, with_nested_markets: bool = True) -> dict:
        return self._get(
            f"/events/{event_ticker}",
            params={"with_nested_markets": str(with_nested_markets).lower()},
        )
