from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass(frozen=True)
class BasketRelation:
    name: str
    tickers: tuple[str, ...]
    exhaustive: bool
    verified_rules_note: str = ""


@dataclass(frozen=True)
class ImplicationRelation:
    name: str
    antecedent: str
    consequent: str
    verified_rules_note: str = ""


@dataclass(frozen=True)
class Relations:
    baskets: tuple[BasketRelation, ...] = ()
    implications: tuple[ImplicationRelation, ...] = ()


def load_relations(path: str | Path | None) -> Relations:
    if path is None:
        return Relations()
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    baskets = tuple(
        BasketRelation(
            name=x["name"],
            tickers=tuple(x["tickers"]),
            exhaustive=bool(x.get("exhaustive", False)),
            verified_rules_note=x.get("verified_rules_note", ""),
        )
        for x in raw.get("baskets", [])
    )
    implications = tuple(
        ImplicationRelation(
            name=x["name"],
            antecedent=x["antecedent"],
            consequent=x["consequent"],
            verified_rules_note=x.get("verified_rules_note", ""),
        )
        for x in raw.get("implications", [])
    )
    return Relations(baskets=baskets, implications=implications)
