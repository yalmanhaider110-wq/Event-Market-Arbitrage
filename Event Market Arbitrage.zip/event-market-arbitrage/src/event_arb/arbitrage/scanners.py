from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Iterable

from event_arb.arbitrage.fees import FeeModel
from event_arb.models import BinaryOrderBook, Opportunity, Side


def _candidate_quantities(legs: list[tuple[BinaryOrderBook, Side]]) -> list[Decimal]:
    """Quantities at which at least one leg moves to a new price level."""
    if not legs:
        return []
    totals: list[Decimal] = []
    breakpoints: set[Decimal] = set()
    for book, side in legs:
        asks = book.yes_asks if side == "yes" else book.no_asks
        running = Decimal("0")
        for level in asks:
            running += level.quantity
            breakpoints.add(running)
        totals.append(running)
    max_common = min(totals, default=Decimal("0"))
    if max_common <= 0:
        return []
    breakpoints.add(max_common)
    return sorted(q for q in breakpoints if Decimal("0") < q <= max_common)


def _cost_and_fees(
    legs: list[tuple[BinaryOrderBook, Side]],
    quantity: Decimal,
    fee_model: FeeModel,
    maker: bool = False,
) -> tuple[Decimal, Decimal] | None:
    total_cost = Decimal("0")
    total_fees = Decimal("0")
    for book, side in legs:
        execution = book.sweep_buy(side, quantity)
        if not execution.fully_filled or execution.average_price is None:
            return None
        total_cost += execution.gross_cost
        total_fees += fee_model.execution_fee(book.ticker, execution.levels_used, maker=maker)
    return total_cost, total_fees


def _best_opportunity(
    opportunity_type: str,
    label: str,
    legs: list[tuple[BinaryOrderBook, Side]],
    payout_per_unit: Decimal,
    fee_model: FeeModel,
    min_net_edge: Decimal,
    min_quantity: Decimal,
    details: dict[str, str] | None = None,
) -> Opportunity | None:
    best: Opportunity | None = None
    for quantity in _candidate_quantities(legs):
        if quantity < min_quantity:
            continue
        calc = _cost_and_fees(legs, quantity, fee_model)
        if calc is None:
            continue
        cost, fees = calc
        payout = payout_per_unit * quantity
        net_profit = payout - cost - fees
        edge = net_profit / quantity
        if edge < min_net_edge:
            continue
        candidate = Opportunity(
            opportunity_type=opportunity_type,
            label=label,
            tickers=tuple(book.ticker for book, _ in legs),
            quantity=quantity,
            gross_cost=cost,
            guaranteed_payout=payout,
            fees=fees,
            net_profit=net_profit,
            net_edge_per_contract=edge,
            observed_at=datetime.now(timezone.utc),
            details=details or {},
        )
        if best is None or candidate.net_profit > best.net_profit:
            best = candidate
    return best


def scan_complement_arbitrage(
    book: BinaryOrderBook,
    fee_model: FeeModel,
    min_net_edge: Decimal = Decimal("0"),
    min_quantity: Decimal = Decimal("1"),
) -> Opportunity | None:
    """Buy YES + NO in the same market; settlement pays exactly $1/unit."""
    return _best_opportunity(
        opportunity_type="binary_complement",
        label=f"YES + NO complement: {book.ticker}",
        legs=[(book, "yes"), (book, "no")],
        payout_per_unit=Decimal("1"),
        fee_model=fee_model,
        min_net_edge=min_net_edge,
        min_quantity=min_quantity,
    )


def scan_exhaustive_basket(
    label: str,
    books: Iterable[BinaryOrderBook],
    exhaustive: bool,
    fee_model: FeeModel,
    min_net_edge: Decimal = Decimal("0"),
    min_quantity: Decimal = Decimal("1"),
    rules_note: str = "",
) -> list[Opportunity]:
    """Scan a verified exactly-one-outcome basket in both directions.

    Underpriced basket: buy YES on every outcome -> exactly one YES pays $1.
    Overpriced basket: buy NO on every outcome -> exactly n-1 NOs pay $1 each.
    """
    books = list(books)
    if not exhaustive or len(books) < 2:
        return []
    details = {"rules_verification": rules_note}
    found: list[Opportunity] = []

    under = _best_opportunity(
        opportunity_type="exhaustive_basket_underpriced",
        label=f"{label} (buy all YES)",
        legs=[(b, "yes") for b in books],
        payout_per_unit=Decimal("1"),
        fee_model=fee_model,
        min_net_edge=min_net_edge,
        min_quantity=min_quantity,
        details=details,
    )
    if under:
        found.append(under)

    over = _best_opportunity(
        opportunity_type="exhaustive_basket_overpriced",
        label=f"{label} (buy all NO)",
        legs=[(b, "no") for b in books],
        payout_per_unit=Decimal(len(books) - 1),
        fee_model=fee_model,
        min_net_edge=min_net_edge,
        min_quantity=min_quantity,
        details=details,
    )
    if over:
        found.append(over)
    return found


def scan_implication_arbitrage(
    label: str,
    antecedent: BinaryOrderBook,
    consequent: BinaryOrderBook,
    fee_model: FeeModel,
    min_net_edge: Decimal = Decimal("0"),
    min_quantity: Decimal = Decimal("1"),
    rules_note: str = "",
) -> Opportunity | None:
    """If A implies B, buy NO(A) + YES(B).

    Payoff is at least $1 per unit in every logically possible state:
    A true -> B true: 0 + 1
    A false, B true: 1 + 1
    B false -> A false: 1 + 0
    """
    return _best_opportunity(
        opportunity_type="logical_implication",
        label=label,
        legs=[(antecedent, "no"), (consequent, "yes")],
        payout_per_unit=Decimal("1"),
        fee_model=fee_model,
        min_net_edge=min_net_edge,
        min_quantity=min_quantity,
        details={"rules_verification": rules_note},
    )


def implication_consistency_signal(
    antecedent: BinaryOrderBook, consequent: BinaryOrderBook
) -> dict[str, str] | None:
    """Non-arbitrage relative-value signal using executable top-of-book bounds.

    If A => B, the probability ordering should satisfy P(A) <= P(B). A clear
    executable inconsistency exists when the best bid for A exceeds the best
    ask for B. This function reports it as a signal even when fees prevent a
    guaranteed-profit trade.
    """
    a_bid = antecedent.best_bid("yes")
    b_ask = consequent.best_ask("yes")
    if a_bid is None or b_ask is None or a_bid <= b_ask:
        return None
    return {
        "antecedent": antecedent.ticker,
        "consequent": consequent.ticker,
        "antecedent_yes_bid": str(a_bid),
        "consequent_yes_ask": str(b_ask),
        "executable_probability_gap": str(a_bid - b_ask),
    }
