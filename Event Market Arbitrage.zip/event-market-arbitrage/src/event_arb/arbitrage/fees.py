from __future__ import annotations

from decimal import Decimal, ROUND_CEILING
from typing import Iterable

from event_arb.models import PriceLevel


class FeeModel:
    """Configurable Kalshi-style event-contract fee model.

    The default general taker formula is rate * contracts * p * (1-p),
    rounded upward to the configured increment. Special markets can have
    different schedules, so per-ticker rate overrides are supported.
    """

    def __init__(
        self,
        taker_rate: Decimal = Decimal("0.07"),
        maker_rate: Decimal = Decimal("0.0175"),
        rounding_increment: Decimal = Decimal("0.01"),
        market_taker_rate_overrides: dict[str, Decimal] | None = None,
    ) -> None:
        self.taker_rate = taker_rate
        self.maker_rate = maker_rate
        self.rounding_increment = rounding_increment
        self.market_taker_rate_overrides = market_taker_rate_overrides or {}

    def _round_up(self, amount: Decimal) -> Decimal:
        if amount <= 0:
            return Decimal("0")
        units = (amount / self.rounding_increment).to_integral_value(rounding=ROUND_CEILING)
        return units * self.rounding_increment

    def trade_fee(
        self,
        price: Decimal,
        contracts: Decimal,
        maker: bool = False,
        rate_override: Decimal | None = None,
    ) -> Decimal:
        if contracts <= 0:
            return Decimal("0")
        if not (Decimal("0") <= price <= Decimal("1")):
            raise ValueError("price must be in [0,1]")
        rate = rate_override if rate_override is not None else (
            self.maker_rate if maker else self.taker_rate
        )
        raw = rate * contracts * price * (Decimal("1") - price)
        return self._round_up(raw)

    def execution_fee(
        self,
        ticker: str,
        levels: Iterable[PriceLevel],
        maker: bool = False,
    ) -> Decimal:
        """Conservative fee estimate for a multi-level sweep.

        Treats each consumed price level as a separately rounded fill. This
        avoids understating fees when one aggressive order matches multiple
        resting price levels.
        """
        override = None if maker else self.market_taker_rate_overrides.get(ticker)
        return sum(
            (self.trade_fee(x.price, x.quantity, maker=maker, rate_override=override) for x in levels),
            start=Decimal("0"),
        )
